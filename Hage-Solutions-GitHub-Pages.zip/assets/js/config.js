window.HAGE_CONFIG = {
  // Coloque aqui o endpoint que vai receber o currículo.
  // Exemplo: https://seu-backend.exemplo.com/api/curriculos
  cvEndpoint: ""
};
