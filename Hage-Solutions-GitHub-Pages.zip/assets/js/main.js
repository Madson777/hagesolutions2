// Hero Background Video Loop Control
        const heroBgVideo = document.getElementById('heroBgVideo');
        if (heroBgVideo) {
            heroBgVideo.currentTime = 3;
            heroBgVideo.addEventListener('timeupdate', function() {
                const maxTime = heroBgVideo.duration > 13 ? (heroBgVideo.duration - 10) : 10;
                if (heroBgVideo.currentTime >= maxTime || heroBgVideo.currentTime < 3) {
                    heroBgVideo.currentTime = 3;
                }
            });
        }

        // CTA Background Video 24s Loop Control
        const ctaBgVideo = document.getElementById('ctaBgVideo');
        if (ctaBgVideo) {
            ctaBgVideo.addEventListener('timeupdate', function() {
                if (ctaBgVideo.currentTime >= 24) {
                    ctaBgVideo.currentTime = 0;
                }
            });
        }

        // WhatsApp Bot Chat Functions
        let chatOpen = false;
        function toggleWhatsappChat() {
            chatOpen = !chatOpen;
            const box = document.getElementById('whatsappChatBox');
            const badge = document.querySelector('.whatsapp-notification-badge');
            if (chatOpen) {
                box.style.display = 'flex';
                if (badge) badge.style.display = 'none';
            } else {
                box.style.display = 'none';
            }
        }

        function handleBotOption(option) {
            const chatBody = document.getElementById('whatsappChatBody');
            const optionsContainer = document.getElementById('whatsappOptions');
            
            if (optionsContainer) optionsContainer.remove();

            let userText = '';
            let botReply = '';
            let nextAction = null;

            if (option === 'servicos') {
                userText = '1. Conhecer Nossos Serviços';
                botReply = 'Oferecemos Gestão e Consultoria Condominial, Portaria & Atendimento, e Limpeza & Conservação. Deseja ser levado até a seção de serviços no site?';
                nextAction = 'services';
            } else if (option === 'sobre') {
                userText = '2. Sobre a Hage Solutions';
                botReply = 'A Hage Solutions possui mais de 26 anos de história fazendo gestão com respeito, dedicação e foco na redução de custos para condomínios. Deseja ver a nossa história?';
                nextAction = 'about';
            } else if (option === 'trabalhe') {
                userText = '3. Trabalhe Conosco (Vagas)';
                botReply = 'Temos oportunidades para Agente de Portaria, Aux. Administrativo, Copeira, Gerente Condominial, Rondante e Serviços Gerais. Deseja ver a seção de vagas?';
                nextAction = 'careers';
            } else if (option === 'humano') {
                userText = '4. Falar com Atendente Humano';
                botReply = 'Excelente! Estou te redirecionando para o nosso atendimento humano via WhatsApp agora mesmo (+55 91 9 8203-6327)...';
                nextAction = 'whatsapp';
            }

            // Append user message
            const userMsgDiv = document.createElement('div');
            userMsgDiv.className = 'whatsapp-msg user';
            userMsgDiv.innerText = userText;
            chatBody.appendChild(userMsgDiv);
            chatBody.scrollTop = chatBody.scrollHeight;

            // Simulate bot reply
            setTimeout(() => {
                const botMsgDiv = document.createElement('div');
                botMsgDiv.className = 'whatsapp-msg bot';
                botMsgDiv.innerHTML = botReply;
                chatBody.appendChild(botMsgDiv);
                chatBody.scrollTop = chatBody.scrollHeight;

                if (nextAction === 'whatsapp') {
                    setTimeout(() => {
                        const redirectMsg = document.createElement('div');
                        redirectMsg.className = 'whatsapp-msg bot';
                        redirectMsg.innerHTML = 'Abrindo conversa no WhatsApp... <br><br><a href="https://wa.me/5591982036327" target="_blank" style="color: #075e54; font-weight: bold; text-decoration: underline;">👉 Clique aqui se não abrir automaticamente</a>';
                        chatBody.appendChild(redirectMsg);
                        chatBody.scrollTop = chatBody.scrollHeight;
                        window.open('https://wa.me/5591982036327', '_blank');
                    }, 1000);
                } else {
                    setTimeout(() => {
                        const newOptionsDiv = document.createElement('div');
                        newOptionsDiv.className = 'whatsapp-options';
                        newOptionsDiv.id = 'whatsappOptions';
                        
                        newOptionsDiv.innerHTML = `
                            <button class="whatsapp-opt-btn" onclick="navigateToSection('${nextAction}')"><i class="fa-solid fa-arrow-right" style="color:#25d366;"></i> Ir para esta seção agora</button>
                            <button class="whatsapp-opt-btn" onclick="handleBotOption('humano')"><i class="fa-brands fa-whatsapp" style="color:#25d366;"></i> Falar com atendente humano (+55 91 9 8203-6327)</button>
                        `;
                        chatBody.appendChild(newOptionsDiv);
                        chatBody.scrollTop = chatBody.scrollHeight;
                    }, 600);
                }
            }, 600);
        }

        function navigateToSection(sectionId) {
            toggleWhatsappChat();
            const el = document.getElementById(sectionId);
            if (el) {
                el.scrollIntoView({ behavior: 'smooth' });
            }
        }

        // Modal Functions
        function openCvModal() {
            document.getElementById('cvModalOverlay').classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeCvModal() {
            document.getElementById('cvModalOverlay').classList.remove('active');
            document.body.style.overflow = 'auto';
            setTimeout(() => {
                document.getElementById('cvForm').style.display = 'block';
                document.getElementById('modalSuccessState').style.display = 'none';
                document.getElementById('cvForm').reset();
                document.getElementById('selectedFileName').innerText = '';
            }, 300);
        }

        function closeCvModalOutside(event) {
            if (event.target === document.getElementById('cvModalOverlay')) {
                closeCvModal();
            }
        }

        function handleFileSelect(event) {
            const file = event.target.files[0];
            const nameDisplay = document.getElementById('selectedFileName');
            if (file) {
                const ext = file.name.split('.').pop().toLowerCase();
                if (['pdf', 'doc', 'docx'].includes(ext)) {
                    nameDisplay.innerText = `Arquivo selecionado: ${file.name}`;
                    nameDisplay.style.color = 'var(--accent)';
                } else {
                    alert('Por favor, selecione apenas arquivos em formato PDF ou Word (.pdf, .doc, .docx).');
                    event.target.value = '';
                    nameDisplay.innerText = '';
                }
            } else {
                nameDisplay.innerText = '';
            }
        }

        async function handleCvSubmit(event) {
            event.preventDefault();
            const endpoint = (window.HAGE_CONFIG && window.HAGE_CONFIG.cvEndpoint) || '';
            if (!endpoint) {
                alert('O formulário está pronto, mas o recebimento do currículo ainda precisa de um endpoint externo. No GitHub Pages, o site é estático e não possui banco de dados próprio. Configure o cvEndpoint em assets/js/config.js antes de publicar.');
                return;
            }
            
            const cvFileInput = document.getElementById('cvFile');
            if (cvFileInput.files.length > 0) {
                const ext = cvFileInput.files[0].name.split('.').pop().toLowerCase();
                if (!['pdf', 'doc', 'docx'].includes(ext)) {
                    alert('Formato de arquivo inválido. Apenas PDF ou Word.');
                    return;
                }
            }

            const form = document.getElementById('cvForm');
            const submitBtn = form.querySelector('.btn-submit-cv');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Enviando...';

            try {
                const formData = new FormData();
                formData.append('fullName', document.getElementById('fullName').value.trim());
                formData.append('phoneNumber', document.getElementById('phoneNumber').value.trim());
                formData.append('cvFile', cvFileInput.files[0]);

                const response = await fetch(endpoint, { method: 'POST', body: formData });
                if (!response.ok) throw new Error('Falha no envio');

                form.style.display = 'none';
                document.getElementById('modalSuccessState').style.display = 'block';
                setTimeout(() => closeCvModal(), 3000);
            } catch (error) {
                console.error(error);
                alert('Não foi possível enviar o currículo agora. Verifique a configuração do formulário e tente novamente.');
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }
        }

        // Máscara para o campo de telefone no formato (xx) x xxxx-xxxx
        const phoneInput = document.getElementById('phoneNumber');
        if (phoneInput) {
            phoneInput.addEventListener('input', function (e) {
                let x = e.target.value.replace(/\D/g, '').match(/(\d{0,2})(\d{0,1})(\d{0,4})(\d{0,4})/);
                e.target.value = !x[2] ? x[1] : '(' + x[1] + ') ' + x[2] + (x[3] ? ' ' + x[3] : '') + (x[4] ? '-' + x[4] : '');
            });
        }

        // Animação de contagem dos números
        function animateCounters() {
            const statNumbers = document.querySelectorAll('.stat-number');
            const duration = 2000;
            const frameRate = 1000 / 60;
            const totalFrames = Math.round(duration / frameRate);

            statNumbers.forEach(counter => {
                const target = counter.getAttribute('data-target');
                const suffix = counter.getAttribute('data-suffix') || '';
                const split = counter.getAttribute('data-target-split');

                if (target) {
                    const targetNum = parseInt(target, 10);
                    let frame = 0;

                    const timer = setInterval(() => {
                        frame++;
                        const progress = frame / totalFrames;
                        const currentNum = Math.floor(targetNum * Math.min(progress, 1));
                        counter.innerText = currentNum + suffix;

                        if (frame >= totalFrames) {
                            counter.innerText = targetNum + suffix;
                            clearInterval(timer);
                        }
                    }, frameRate);
                } else if (split) {
                    const parts = split.split('/');
                    const num1 = parseInt(parts[0], 10);
                    const num2 = parseInt(parts[1], 10);
                    let frame = 0;

                    const timer = setInterval(() => {
                        frame++;
                        const progress = frame / totalFrames;
                        const cur1 = Math.floor(num1 * Math.min(progress, 1));
                        const cur2 = Math.floor(num2 * Math.min(progress, 1));
                        counter.innerText = `${cur1}/${cur2}`;

                        if (frame >= totalFrames) {
                            counter.innerText = split;
                            clearInterval(timer);
                        }
                    }, frameRate);
                }
            });
        }

        const statsSection = document.querySelector('.stats-section');
        let countersAnimated = false;

        if (statsSection) {
            const statsObserver = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting && !countersAnimated) {
                        animateCounters();
                        countersAnimated = true;
                    }
                });
            }, { threshold: 0.3 });

            statsObserver.observe(statsSection);
        }

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // Scroll Reveal Animation
        const observerOptions = {
            threshold: 0.15,
            rootMargin: "0px 0px -50px 0px"
        };

        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                    observer.unobserve(entry.target);
                }
            });
        }, observerOptions);

        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

        // Filter Services Tabs
        function filterServices(category) {
            const buttons = document.querySelectorAll('.tab-btn');
            buttons.forEach(btn => btn.classList.remove('active'));
            event.target.classList.add('active');

            const cards = document.querySelectorAll('.service-card');
            cards.forEach(card => {
                const cardCat = card.getAttribute('data-category');
                if (category === 'all' || cardCat === category) {
                    card.style.display = 'flex';
                    setTimeout(() => {
                        card.style.opacity = '1';
                        card.style.transform = 'translateY(0)';
                    }, 50);
                } else {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(20px)';
                    setTimeout(() => {
                        card.style.display = 'none';
                    }, 300);
                }
            });
        }

        // Video Player Controls
        const video = document.getElementById('bgVideo');
        const playPauseBtn = document.getElementById('playPauseBtn');
        const muteBtn = document.getElementById('muteBtn');

        function togglePlay() {
            if (video.paused) {
                video.play();
                playPauseBtn.innerHTML = '<i class="fa-solid fa-pause"></i>';
            } else {
                video.pause();
                playPauseBtn.innerHTML = '<i class="fa-solid fa-play"></i>';
            }
        }

        function toggleMute() {
            if (video.muted) {
                video.muted = false;
                muteBtn.innerHTML = '<i class="fa-solid fa-volume-high"></i>';
            } else {
                video.muted = true;
                muteBtn.innerHTML = '<i class="fa-solid fa-volume-xmark"></i>';
            }
        }

        // Mobile navigation
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const mobileNav = document.getElementById('mobileNav');
        if (mobileMenuToggle && mobileNav) {
            mobileMenuToggle.addEventListener('click', () => {
                const open = mobileNav.classList.toggle('open');
                mobileMenuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
                mobileMenuToggle.innerHTML = open ? '<i class="fa-solid fa-xmark"></i>' : '<i class="fa-solid fa-bars"></i>';
            });
            mobileNav.querySelectorAll('a[href^="#"]').forEach(link => {
                link.addEventListener('click', () => {
                    mobileNav.classList.remove('open');
                    mobileMenuToggle.setAttribute('aria-expanded', 'false');
                    mobileMenuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
                });
            });
        }

        // Pause heavy background videos when they leave the viewport.
        if ('IntersectionObserver' in window) {
            document.querySelectorAll('video[autoplay]').forEach(v => {
                const io = new IntersectionObserver(entries => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            v.play().catch(() => {});
                        } else if (!v.paused) {
                            v.pause();
                        }
                    });
                }, {threshold: 0.05});
                io.observe(v);
            });
        }

        // Close mobile navigation with Escape.
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && mobileNav && mobileNav.classList.contains('open')) {
                mobileNav.classList.remove('open');
                mobileMenuToggle.setAttribute('aria-expanded', 'false');
                mobileMenuToggle.innerHTML = '<i class="fa-solid fa-bars"></i>';
            }
        });
